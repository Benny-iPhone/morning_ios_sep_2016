//
//  ViewController.swift
//  DateConvertor
//
//  Created by Benny Davidovitz on 22/09/2016.
//  Copyright © 2016 xcoder.solutions. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var label: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    @IBAction func datePickerValueChangedAction(_ sender: UIDatePicker) {
        
        let dateFormatter = DateFormatter() //NSDateFormatter
        dateFormatter.calendar = Calendar(identifier: .hebrew)
        //dateForamtter.calendar = NSCalendar(identifier: NSCalendarIdentifierHebrew)
        
        dateFormatter.dateStyle = .full
                                //.FullStyle
        
        dateFormatter.locale = Locale(identifier: "he")
        //            = NSLocal   e(localeIdentifier: "he")
        
        label.text = dateFormatter.string(from: sender.date)
        //dateFormatter.stringFromDate(sender.date)
        
    }
    


}












